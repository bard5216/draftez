#
# For development only use flask run or app.run()
# For production use gunicorn or uwsgi
# Alternatives:
# If using apache then mod_wsgi is easy to setup.
#
# env FLASK_APP=run FLASK_ENV=development flask run

# if there is a global app object

echo "############################################"
echo "#"
echo "#  Is redis running?"
echo "#  Start with:"
echo "#    redis-server --port 6380"
echo "#"
echo "############################################"
env FLASK_ENV=development flask run --with-threads

