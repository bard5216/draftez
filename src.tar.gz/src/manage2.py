from flask_migrate import Migrate, MigrateCommand
from flask_script import Manager

from app import app
from app.models import db
from app.models.settings import Settings  # noqa: F401
from app.models.user import User  # noqa: F401
from app.models.conference import Conference  # noqa: F401
from app.models.division import Division  # noqa: F401
from app.models.team import Team  # noqa: F401
from app.models.player import Player  # noqa: F401
from app.models.pick import Pick  # noqa: F401
from app.models import Log  # noqa: F401
from app.models import Status  # noqa: F401


migrate = Migrate(app, db)
manager = Manager(app)
manager.add_command('db', MigrateCommand)

if __name__ == '__main__':
    manager.run()
