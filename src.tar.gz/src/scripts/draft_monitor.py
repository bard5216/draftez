"""
Send periodic status messages.
flask-sse uses a StrictRedis instance. StrictRedis is an alias for Redis.
"""
import time
from redis import Redis
from flask import current_app, json  # stream_with_context
from app.helpers.messages import DraftStatusMessage

from app import app
from app.models import User, db
from app.helpers.util import (
    get_status_val,
    get_current_state,
    get_current_round,
    get_next_drafting
)


def get_user_by_pos(pos):
    u = User.query.filter(User.pos == pos).one()
    return u


def main():
    seq = 0
    redis_url = current_app.config.get("SSE_REDIS_URL")
    if not redis_url:
        raise KeyError("Must set a redis connection URL in app config.")
    redis = Redis.from_url(redis_url)

    user = User.query.get(1)
    # player = Player.query.get(8466139)
    print(user)

    while True:
        # now = datetime.datetime.now(pytz.utc)
        # ts_now = datetime.datetime.now(pytz.utc).strftime("%Y-%m-%d %H:%M:%S")

        # param type: An optional event type
        # id: An optional event ID
        # message = Message(data, type=type, id=id, retry=retry)
        seq += 1
        # data = {"msg": "some message", "id": id, "ts": f"{ts_now}"}
        # message = Message(data, type="draft-status")
        current_pos = get_status_val("current_drafting")
        # current_drafting = get_current_drafting()
        next_drafting = get_next_drafting()
        print(f"draft_monitor: current_drafting={current_pos}")

        cur_user = get_user_by_pos(current_pos)
        # cur_user = User.query.filter(User.pos == current_drafting).one()
        next_user = User.query.filter(User.pos == next_drafting).one()
        message = DraftStatusMessage(seq, get_current_state(), get_current_round(),
                                     current_user=cur_user, next_user=next_user)
        msg_json = json.dumps(message.to_dict())
        # print(f"{ts_now}:  publishing {msg_json}")
        redis.publish(channel="sse", message=msg_json)
        db.session.commit()
        time.sleep(5)


if __name__ == '__main__':
    with app.app_context():
        main()
