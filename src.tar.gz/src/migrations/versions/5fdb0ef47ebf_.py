"""empty message

Revision ID: 5fdb0ef47ebf
Revises: 
Create Date: 2021-03-29 22:27:12.347849

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '5fdb0ef47ebf'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
