"""empty message

Revision ID: 9dd87eda5e03
Revises: 5fdb0ef47ebf
Create Date: 2021-03-29 22:27:47.783446

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '9dd87eda5e03'
down_revision = '5fdb0ef47ebf'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
