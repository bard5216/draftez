from dotenv import load_dotenv
from flask import Flask
from flask_script import Manager
from flask_migrate import Migrate, MigrateCommand

# from app.application import app
# from app import db, app
from app.models import db

# from app.models.user import User
# from app.models.pick import Pick

load_dotenv()
app = Flask(__name__)
config = "config.DevelopmentConfig"
app.config.from_object(config)
db.init_app(app)

migrate = Migrate(app, db)
manager = Manager(app)
manager.add_command('db', MigrateCommand)


if __name__ == '__main__':
    manager.run()
