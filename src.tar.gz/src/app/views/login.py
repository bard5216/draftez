# import logging
from flask import (
    Blueprint,
    render_template,
    request,
    redirect,
    url_for,
    flash
)
from flask_login import login_user

from app.models.user import User


login_bp = Blueprint("login", __name__, url_prefix="/login")


@login_bp.route("/", methods=["GET", "POST"])
def login():
    if (request.method == 'POST'):
        print("login request is")
        print(request.form)

        # authenticate request.form['email']
        user = User.query.filter(User.username == request.form['email'])
        if user.count() == 1:
            login_user(user.one(), remember=True)
            flash(f"{user.one().username} Logged In")
            next = request.args.get("next")
            return redirect(next or url_for('index.index'))
        else:
            flash("Invalid login")

        """
        if (user is not None):
            print("found user=",user)
            login_user(user)
            next = request.args.get("next")
            return redirect(next or url_for('index.index'))
        """

    return render_template("login_bulma.html")
    # return render_template("login5.html")
