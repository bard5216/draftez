from flask import Blueprint, render_template, request, jsonify
from flask_login import current_user
from flask_sse import sse

from app.models import db
from app.models.player import Player
from app.models.pick import Pick
from app.helpers.jsonable import JSONAble


api_bp = Blueprint("api", __name__, url_prefix="/api")


class DraftMsg(JSONAble):
    user_id = 0
    user_name = ""
    player_id = 0
    player_name = ""
    player_team = ""
    round = 0
    """
    user
    player
    round
    """
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)


@api_bp.route("/playersearch", methods=["GET"])
def players(search=""):
    search = request.args.get("search")
    results = Player.query.filter(Player.last_name.like(f"%{search}%")).order_by(Player.last_name).all()
    return render_template("api/search_results.html", players=results)


@api_bp.route("/playersearch_json", methods=["GET"])
def players_json():
    search = request.args.get("q")
    if len(search) <= 1:
        return jsonify({"results": []}), 200
    players = Player.query.filter(Player.last_name.like(f"%{search}%")).order_by(Player.points.desc()).all()
    res = [{"name": p.full_name,
            "id": p.id,
            "text": f"{p.full_name} ({p.team.abbrev})",
            "games": p.games,
            "goals": p.goals,
            "assists": p.assists,
            "points": p.points,
            "team_abbrev": p.team.abbrev,
            "team_name": p.team.name,
            "team_id": p.team.id} for p in players]

    return jsonify({"results": res}), 200


@api_bp.route("/draft_player", methods=["POST"])
def draft_player():
    print(f"/api/draftpick: json={request.get_json()}")
    data = request.get_json()
    player_id = data['player_id']

    pick = Pick(round=1, user_id=current_user.id, player_id=data['player_id'])
    db.session.add(pick)
    db.session.commit()
    player = Player.query.filter(Player.id == player_id).one()
    # notice_msg = "{0} selected {1} from {2}".format(current_user.display_name, player.full_name, player.team.name)
    msg = DraftMsg(user_id=current_user.id, user_name=current_user.display_name,
                   player_id=player.id, player_name=player.full_name, player_team=player.team.name,
                   round=0)
    sse.publish(msg.toJSON(), type="draftpick")
    # sse.publish({"message": notice_msg})
    return jsonify({}), 200


@api_bp.route("/teams/<int:team_id>/roster", methods=["GET"])
def team_roster(team_id):
    players = Player.query.filter(Player.team_id == team_id).order_by(Player.points.desc()).all()
    return render_template("partials/team_roster.html", roster=players)


@api_bp.route("/picks/<int:user_id>", methods=["GET"])
def user_picks(user_id):
    """
    for pick, player = db.session.query(Pick, Player).\
                                  filter(Pick.user_id==user_id).\
                                  filter(Pick.player_id==Player.id).\
                                  all():
    """

    """
    Pick.query.filter(Pick.user_id == user_id)
    select user.display_name, player.full_name, pick.round from pick
    inner join player on pick.player_id = player.id
    inner join user on pick.user_id = user.id
    """

    # picks = Pick.query.filter(Pick.user_id == user_id).order_by(Pick.round).all()
    picks = []

    return render_template("partials/user_picks.html", picks=picks)
