from config import Config
from dotenv import load_dotenv
from flask import Flask
from flask_login import LoginManager
from flask_cors import CORS
from flask_sse import sse
# from flask_assets import Bundle, Environment

from app.helpers.auth import AuthManager
from .models import db


def create_app():
    """Create application factory, as explained here:
    http://flask.pocoo.org/docs/patterns/appfactories/.

    :param config_object: The configuration object to use.
    """

    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager = LoginManager()
    login_manager.login_view = "login.login"

    """
    @login_manager.user_loader
    def load_user(user_id):
        from app.models.user import User

        print(f"login_manager.user_loader: user_id={user_id}")
        user = User.query.filter(User.id == user_id).first()
        return user
    """

    AuthManager.init_login(app)

    """
    assets = Environment(app)
    # All Bundle paths are relative to your app’s static directory, or the static directory of a Flask blueprint.
    js = Bundle('jquery.js', 'base.js', 'widgets.js',
                filters='jsmin', output='gen/packed.js')
    assets.register('js_all', js)
    """

    with app.app_context():
        from .views.admin import admin_bp
        from .views.index import index_bp
        from .views.login import login_bp
        from .views.api import api_bp

        CORS(app, resources={r"/*": {"origins": "*"}})
        db.init_app(app)

        app.register_blueprint(index_bp)
        app.register_blueprint(login_bp)
        app.register_blueprint(api_bp)
        app.register_blueprint(admin_bp)
        app.register_blueprint(sse, url_prefix="/stream")

    return app


load_dotenv(verbose=True)
app = Flask(__name__)
app.config.from_object(Config)
# print(f"app.config={app.config}")
# app.config["REDIS_URL"] = "redis://localhost:6380"
# print(f"env redis_url={os.getenv('SSE_REDIS_URL')}")
# print(f"app.config redis_url={app.config['SSE_REDIS_URL']}")


app = create_app()
