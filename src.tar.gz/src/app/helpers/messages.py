import datetime
from flask_sse import Message


class DraftStatusMessage(Message):
    """
    current_user is the user currently drafting
    next_user is the user next up to draft
    """
    def __init__(self, seq, state, round, current_user=None, next_user=None):
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        data = {
            "seq": seq,
            "ts": ts,
            "round": round,
            "state": state,
        }
        if current_user is not None:
            data["current_user"] = {"id": current_user.id, "name": current_user.display_name}
        if next_user is not None:
            data["next_user"] = {"id": next_user.id, "name": next_user.display_name}
        super().__init__(data, type="draft-status")


class DraftpickMessage(Message):
    # def __init__(self, seq, draft_round, user=None, player=None):
    def __init__(self, seq, draft_round, user, player):
        if user is None or player is None:
            raise KeyError("user and player must be set")
        data = {
            "seq": seq,
            "round": draft_round,
            "user": {
                "id": user.id,
                "name": user.display_name,
            },
            "player": {
                "id": player.id,
                "name": player.full_name,
                "team_id": player.team.id,
                "team_name": player.team.name,
                "team_abbrev": player.team.abbrev
            }
        }
        super().__init__(data, type="draft-pick")


class DraftUsersMessage(Message):
    def __init__(self, users=None):
        if users is None or not isinstance(users, list):
            raise KeyError("users must be a list of user")

        user_list = []
        for u in users:
            user_list.append(u.as_dict_public())

        data = {
            "users": user_list
        }
        super().__init__(data, type="draft-users")
