from functools import wraps
from flask import current_app
from flask_login import LoginManager
from flask_login import current_user

from app.models.user import User


class AuthManager:
    def __init__(self):
        pass

    @staticmethod
    def init_login(app):

        login_manager = LoginManager()
        login_manager.init_app(app)

        @login_manager.user_loader
        def load_user(user_id):
            # return db.session.query(User).get(user_id)
            return User.query.filter(User.id == user_id).first()


def second_order_decorator(inner_dec):
    """
    Second order decorator. Decorator to apply on a decorator.
    https://stackoverflow.com/questions/5952641/decorating-decorators-try-to-get-my-head-around-understanding-it
    :param inner_dec:
    :return:
    """

    def ddmain(outer_dec):
        def decwrapper(f):
            wrapped = inner_dec(outer_dec(f))

            def fwrapper(*args, **kwargs):
                return wrapped(*args, **kwargs)

            return fwrapper

        return decwrapper

    return ddmain


def is_admin(f):
    '''
    If you decorate a view with this, it will ensure that the current user is
    logged in and authenticated and is an admin before calling the actual view. (If they are
    not, it calls the :attr:`LoginManager.unauthorized` callback.) For
    example::

        @app.route('/post')
        @login_required
        def post():
            pass

    If there are only certain times you need to require that your user is
    logged in, you can do so with::

        if not current_user.is_authenticated:
            return current_app.login_manager.unauthorized()

    ...which is essentially the code that this function adds to your views.

    It can be convenient to globally turn off authentication when unit testing.
    To enable this, if the application configuration variable `LOGIN_DISABLED`
    is set to `True`, this decorator will be ignored.

    .. Note ::

        Per `W3 guidelines for CORS preflight requests
        <http://www.w3.org/TR/cors/#cross-origin-request-with-preflight-0>`_,
        HTTP ``OPTIONS`` requests are exempt from login checks.

    :param func: The view function to decorate.
    :type func: function
    '''

    @wraps(f)
    def decorated_function(*args, **kwargs):
        user = current_user
        if not user.admin:
            return current_app.login_manager.unauthorized()
        return f(*args, **kwargs)

    return decorated_function
