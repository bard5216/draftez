from app.models import Status, User


def pretty_print_POST(req):
    """
    At this point it is completely built and ready
    to be fired; it is "prepared".

    However pay attention at the formatting used in
    this function because it is programmed to be pretty
    printed and may differ from the actual request.
    """
    print('{}\n{}\r\n{}\r\n\r\n{}'.format(
        '-----------START-----------',
        req.method + ' ' + req.url,
        '\r\n'.join('{}: {}'.format(k, v) for k, v in req.headers.items()),
        req.body,
    ))


def get_users():
    users = Users.query.all()
    u_list = [u.as_dict_public() for u in users]
    return u_list


def get_status_val(k, int_val=False):
    print("get_status_val")
    status = Status.query.filter(Status.k == k).one()
    print(f"get_status_val: v={status.v}")
    if int_val:
        return int(status.v)
    return status.v


def get_current_round():
    status = Status.query.filter(Status.k == "round").first()
    return int(status.v)


def get_current_state():
    status = Status.query.filter(Status.k == "state").first()
    return status.v


def get_draftee_count():
    status = Status.query.filter(Status.k == "draftee_count").first()
    return int(status.v)


def get_current_drafting():
    """
    Return the draft position of current draftee
    """
    status = Status.query.filter(Status.k == "current_drafting").first()
    return int(status.v)


def get_draft_direction():
    status = Status.query.filter(Status.k == "draft_direction").first()
    draft_direction = status.v  # "forward" "reverse"
    return draft_direction


def get_next_drafting():
    cur = get_current_drafting()  # pos of current drafting
    # n = get_draftee_count()
    dir = get_draft_direction()

    if dir == "forward":
        """
        In this direction cur should always be < n
        """
        next = cur + 1
    else:
        next = cur - 1

    return next
