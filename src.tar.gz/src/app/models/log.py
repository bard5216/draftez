from sqlalchemy import func
from app.models import db


class Log(db.Model):
    __tablename__ = 'log'

    id = db.Column(db.Integer, primary_key=True)
    # actions: "pick"
    action = db.Column(db.String(20), nullable=False)
    round = db.Column(db.Integer, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    # if action=="pick"
    player_id = db.Column(db.Integer, db.ForeignKey('player.id'), nullable=False)

    created_at = db.Column(db.DateTime(timezone=True), default=func.now())

    player = db.relationship("Player")
    user = db.relationship("User")

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "<Settings_{0}>".format(self.id)

    def __str__(self):
        return self.__repr__()
