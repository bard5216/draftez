from app.models import db


class Settings(db.Model):
    __tablename__ = 'settings'

    id = db.Column(db.Integer, primary_key=True)
    user_count = db.Column(db.Integer)
    max_rounds = db.Column(db.Integer)
    current_round = db.Column(db.Integer)
    isopen = db.Column(db.Integer)
    site_password = db.Column(db.String(64))
    site_id = db.Column(db.Integer)
    invite_password = db.Column(db.String(64))

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "<Settings_{0}>".format(self.id)

    def __str__(self):
        return self.__repr__()
