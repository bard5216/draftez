from app.models import db


class Player(db.Model):
    __tablename__ = 'player'

    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(64), nullable=False)
    first_name = db.Column(db.String(64))
    last_name = db.Column(db.String(64))
    team_id = db.Column(db.Integer, db.ForeignKey('team.id'), nullable=False)
    position = db.Column(db.String(16), nullable=False)

    season = db.Column(db.String(16), nullable=True)
    games = db.Column(db.Integer, nullable=True)
    goals = db.Column(db.Integer, nullable=True)
    assists = db.Column(db.Integer, nullable=True)
    points = db.Column(db.Integer, nullable=True)

    team = db.relationship('Team', back_populates='players')

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "<Player_{0}:{1}>".format(self.id, self.full_name)

    def __str__(self):
        return self.__repr__()
