from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import MetaData


convention = {
    "ix": 'ix_%(column_0_label)s',
    "uq": "uq_%(table_name)s_%(column_0_name)s",
    # "ck": "ck_%(table_name)s_%(constraint_name)s",
    # "fk": "fk_%(table_name)s_%(column_0_name)s_%(referred_table_name)s",
    "fk": "fk_%(table_name)s_%(column_0_name)s",
    "pk": "pk_%(table_name)s"
}
metadata = MetaData(naming_convention=convention)

# db is an instance of flask_sqlalchemy.SQLAlchemy
# db = SQLAlchemy(app)
db = SQLAlchemy(metadata=metadata)

from .user import User  # noqa: F401 E402
from .settings import Settings  # noqa: F401 E402
from .player import Player  # noqa: F401 E402
from .division import Division  # noqa: F401 E402
from .team import Team  # noqa: F401 E402
from .pick import Pick  # noqa: F401 E402
from .log import Log  # noqa: F401 E402
from .status import Status  # noqa: F401 E402
