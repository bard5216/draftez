from sqlalchemy import func
from flask_login import UserMixin
from . import db


# class User(db.Model, UserMixin):
class User(db.Model, UserMixin):
    __tablename__ = 'user'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    display_name = db.Column(db.String(64), unique=True, nullable=False)
    # 80 char password to accommodate sha256 hash
    password = db.Column(db.String(80))
    pos = db.Column(db.Integer, nullable=False, default=0)
    admin = db.Column(db.Integer, nullable=False, default=0)
    registered = db.Column(db.Integer, nullable=False, default=0)
    active = db.Column(db.Integer, nullable=False, default=0)
    last_seen = db.Column(db.DateTime(timezone=True), default=func.now())
    # isactive = db.Column(db.Integer)

    """
    # Flask-Login integration
    @property
    def is_authenticated(self):
        return True

    def is_active(self):
        return True

    def is_anonymous(self):
        return False

    def get_id(self):
        return self.id
    """

    def is_selecting(self):
        """
        Currently draft selecting.
        """
        return True

    def as_dict_public(self):
        cols = ['id', 'username', 'display_name', 'pos']
        return {c.name: getattr(self, c.name) for c in cols}

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "<User_{0}:{1}>".format(self.id, self.username)

    def __str__(self):
        return self.__repr__()
