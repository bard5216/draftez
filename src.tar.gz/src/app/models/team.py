from app.models import db
# from app.models.player import Player
# from app.models.division import Division


class Team(db.Model):
    __tablename__ = 'team'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True, nullable=False)
    shortname = db.Column(db.String(16), unique=True, nullable=False)
    abbrev = db.Column(db.String(3), unique=True, nullable=False)
    division_id = db.Column(db.Integer, db.ForeignKey('division.id'), nullable=False)
    in_playoffs = db.Column(db.Boolean, nullable=False, default=1)

    division = db.relationship('Division', back_populates='teams')
    players = db.relationship('Player')

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "<Team_{0}:{1}>".format(self.id, self.abbrev)

    def __str__(self):
        return self.__repr__()
