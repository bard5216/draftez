from app.models import db


class Status(db.Model):
    __tablename__ = 'status'

    id = db.Column(db.Integer, primary_key=True)
    k = db.Column(db.String(64), unique=True, nullable=False)
    v = db.Column(db.String(64))

    def as_dict(self):
        return {c.name: getattr(self, c.name) for c in self.__table__.columns}

    def __repr__(self):
        return "<Status_{0}_{1}_{2}>".format(self.id, self.k, self.v)

    def __str__(self):
        return self.__repr__()
