SET FOREIGN_KEY_CHECKS = 0;
truncate player;
truncate division;
truncate conference;
truncate team;
SET FOREIGN_KEY_CHECKS = 1;
